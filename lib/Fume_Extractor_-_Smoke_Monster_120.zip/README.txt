                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2602977
Fume Extractor - Smoke Monster 120 by Looper is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

This is a combination of two really neat fume extractor designs.  I wanted the features of both designs in one item.  To do this I completely redrew the parts in Fusion360 to allow for the stand up or layover design that NRP created and the battery powered features that Marsupilami created.  The portability of this fume extractor will complement my TS100 soldering iron.

# Post-Printing

## Vitamin List (because Mike hates that phrase)

[Boost Converter](https://smile.amazon.com/gp/product/B06WD5XXRR) 
[1S Battery Display](https://smile.amazon.com/gp/product/B06Y17Y28M)
[Battery Protection / Charger](https://smile.amazon.com/gp/product/B00SR4FH4A)
[18650 Holder](https://smile.amazon.com/gp/product/B013DUOJV4)
[18650 battery](https://smile.amazon.com/gp/product/B01NCZHSPY)
[Slide Switch](https://smile.amazon.com/uxcell®-Pins-Positions-Slide-Switch/dp/B008P720ZS)
[Carbon Filter](https://smile.amazon.com/gp/product/B014RKCR1I)
[120mm Fan](https://smile.amazon.com/gp/product/B00KB8CB9O)

## Moar detailed build instructions.

Please check out Marsupilami thing at https://www.thingiverse.com/thing:2490759 and http://www.instructables.com/id/DIY-Battery-Powered-Solder-Fume-Extractor/ for detailed instructions and wiring diagrams.  He's has done a really nice video on the assembly process.